const Schedule = require('../models/schedule');
const asyncHandler = require('express-async-handler');

exports.schedule_list = asyncHandler(async (req, res, next) => {
  try {
    const fullSchedule = await Schedule.find({}, 'week dow topic').exec();

    const sortedSchedule = fullSchedule.sort((a, b) => {
      if (a.week !== b.week) {
        return a.week - b.week; // Sort by week number first
      } else {
        // Compare days of the week using if statements
        const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
        const dayA = days.indexOf(a.dow);
        const dayB = days.indexOf(b.dow);

        if (dayA < dayB) {
          return -1;
        } else if (dayA > dayB) {
          return 1;
        } else {
          return 0;
        }
      }
    });
   console.log(sortedSchedule);

    // Send the sorted schedule data to the Pug file
    res.render('schedule', { schedule: sortedSchedule });
  } catch (err) {
    console.error(err);
    res.status(500).send('Internal Server Error');
  }
});

