var express = require('express');
var router = express.Router();
const schedule_controller = require("../controllers/scheduleController");

/* GET home page. */
router.get('/', function(req, res, next) {
  console.log('Current Page:', 'home');
  res.render('index', { title: 'Express', currentRoute: '/' });
});

router.get('/schedule', schedule_controller.schedule_list);

router.get('/syllabus', (req, res) => {
  console.log('Current Page:', 'syllabus');
  res.render('syllabus', { currentRoute: '/syllabus'});
});

router.get('/study', (req, res) => {
  console.log('Current Page:', 'study');
  res.render('study', { currentRoute: '/study'});
});

module.exports = router;
